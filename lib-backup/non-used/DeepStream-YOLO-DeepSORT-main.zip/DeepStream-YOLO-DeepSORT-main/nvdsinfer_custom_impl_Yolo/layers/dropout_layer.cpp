/*
 * Created by Marcos Luciano
 * https://www.github.com/marcoslucianops
 */

#include "dropout_layer.h"

nvinfer1::ILayer* dropoutLayer(
    float probability,
    nvinfer1::ITensor* input,
    nvinfer1::INetworkDefinition* network)
{
    nvinfer1::ILayer* output;
    return output;
}
