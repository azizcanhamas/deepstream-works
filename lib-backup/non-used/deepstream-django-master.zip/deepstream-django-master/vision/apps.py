from django.apps import AppConfig


class VisionConfig(AppConfig):
    name = 'vision'
