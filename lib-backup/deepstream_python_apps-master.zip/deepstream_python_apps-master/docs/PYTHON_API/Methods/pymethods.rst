==================
Methods
==================

.. toctree::
	methodsdoc
